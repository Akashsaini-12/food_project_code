import { View, Text } from 'react-native'
import React from 'react'

const Signup = () => {
  return (
    <View>
      <Text>Signup</Text>
    </View>
  )
}

export default Signup